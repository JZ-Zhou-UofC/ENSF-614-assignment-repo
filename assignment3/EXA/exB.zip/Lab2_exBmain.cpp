/*
*
*
File Name: Lab2_exBmain.cpp
Assignment: Lab 2 Exercise B
*  Completed by: John Zhou
*  Submission Date: Sept 24, 2025
*/
#include "graphicsWorld.h"

int main() {
    GraphicsWorld gw;
    gw.run();
    return 0;
}
