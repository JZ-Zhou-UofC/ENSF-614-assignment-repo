/*
*
*
File Name: graphicsWorld.h
Assignment: Lab 2 Exercise B
*  Completed by: John Zhou
*  Submission Date: Sept 24, 2025
*/
#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H

class GraphicsWorld {
public:
    void run();
};

#endif
