package EB;
import java.awt.Graphics;


public interface Component {
    void draw(Graphics g);
}
