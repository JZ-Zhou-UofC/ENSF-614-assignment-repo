/*
*
*
File Name: Component.java
Assignment: Lab 6 Exercise A&B
*  Completed by: John Zhou
*  Submission Date: Nov 5th, 2025
*/
package EA;
import java.awt.Graphics;


public interface Component {
    void draw(Graphics g);
}
