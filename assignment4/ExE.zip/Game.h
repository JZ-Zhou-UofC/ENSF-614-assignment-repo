class Game {
public:
    Player* create_player(char mark, Board *board);
};
